#include <algorithm>

namespace algs {

template<class T>
T parallel_find(vector<int> list)
{

}

template<class T>
void parallel_sort(vector<int> list);

}
